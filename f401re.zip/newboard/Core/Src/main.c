#include "main.h"

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;

/* Function prototypes */
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);

/* ILI9341 Functions */
void ILI9341_WriteCommand(uint8_t cmd);
void ILI9341_WriteData(uint8_t data);
void ILI9341_Reset(void);
void ILI9341_Init(void);
void ILI9341_SetAddress(uint16_t x1,uint16_t y1,uint16_t x2,uint16_t y2);
void ILI9341_FillColor(uint16_t color);

/* MAIN */
int main(void)
{
  HAL_Init();
  SystemClock_Config();

  MX_GPIO_Init();
  MX_SPI1_Init();

  ILI9341_Reset();
  ILI9341_Init();

  while (1)
  {
    ILI9341_FillColor(0xF800); // RED
    HAL_Delay(1000);

    ILI9341_FillColor(0x07E0); // GREEN
    HAL_Delay(1000);

    ILI9341_FillColor(0x001F); // BLUE
    HAL_Delay(1000);
  }
}

/* ---------------- DISPLAY DRIVER ---------------- */

void ILI9341_Reset(void)
{
  HAL_GPIO_WritePin(DISP_NRESET_GPIO_Port, DISP_NRESET_Pin, GPIO_PIN_RESET);
  HAL_Delay(20);
  HAL_GPIO_WritePin(DISP_NRESET_GPIO_Port, DISP_NRESET_Pin, GPIO_PIN_SET);
  HAL_Delay(120);
}

void ILI9341_WriteCommand(uint8_t cmd)
{
  HAL_GPIO_WritePin(SPI1_DCX_GPIO_Port, SPI1_DCX_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(SPI1_NCS_GPIO_Port, SPI1_NCS_Pin, GPIO_PIN_RESET);
  HAL_SPI_Transmit(&hspi1, &cmd, 1, HAL_MAX_DELAY);
  HAL_GPIO_WritePin(SPI1_NCS_GPIO_Port, SPI1_NCS_Pin, GPIO_PIN_SET);
}

void ILI9341_WriteData(uint8_t data)
{
  HAL_GPIO_WritePin(SPI1_DCX_GPIO_Port, SPI1_DCX_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(SPI1_NCS_GPIO_Port, SPI1_NCS_Pin, GPIO_PIN_RESET);
  HAL_SPI_Transmit(&hspi1, &data, 1, HAL_MAX_DELAY);
  HAL_GPIO_WritePin(SPI1_NCS_GPIO_Port, SPI1_NCS_Pin, GPIO_PIN_SET);
}

void ILI9341_Init(void)
{
  ILI9341_WriteCommand(0x01); // Software reset
  HAL_Delay(100);

  ILI9341_WriteCommand(0x28); // Display OFF

  ILI9341_WriteCommand(0x3A); // Pixel format
  ILI9341_WriteData(0x55);    // 16-bit

  ILI9341_WriteCommand(0x36); // Memory Access Control
  ILI9341_WriteData(0x48);

  ILI9341_WriteCommand(0x11); // Sleep out
  HAL_Delay(120);

  ILI9341_WriteCommand(0x29); // Display ON
}

void ILI9341_SetAddress(uint16_t x1,uint16_t y1,uint16_t x2,uint16_t y2)
{
  ILI9341_WriteCommand(0x2A);
  ILI9341_WriteData(x1>>8); ILI9341_WriteData(x1);
  ILI9341_WriteData(x2>>8); ILI9341_WriteData(x2);

  ILI9341_WriteCommand(0x2B);
  ILI9341_WriteData(y1>>8); ILI9341_WriteData(y1);
  ILI9341_WriteData(y2>>8); ILI9341_WriteData(y2);

  ILI9341_WriteCommand(0x2C);
}

void ILI9341_FillColor(uint16_t color)
{
  ILI9341_SetAddress(0,0,239,319);

  uint8_t data[2];
  data[0] = color >> 8;
  data[1] = color & 0xFF;

  HAL_GPIO_WritePin(SPI1_DCX_GPIO_Port, SPI1_DCX_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(SPI1_NCS_GPIO_Port, SPI1_NCS_Pin, GPIO_PIN_RESET);

  for(uint32_t i=0;i<240*320;i++)
  {
    HAL_SPI_Transmit(&hspi1,data,2,HAL_MAX_DELAY);
  }

  HAL_GPIO_WritePin(SPI1_NCS_GPIO_Port, SPI1_NCS_Pin, GPIO_PIN_SET);
}

/* ---------------- SPI INIT ---------------- */

static void MX_SPI1_Init(void)
{
  __HAL_RCC_SPI1_CLK_ENABLE();

  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;

  if (HAL_SPI_Init(&hspi1) != HAL_OK)
    Error_Handler();
}

/* ---------------- GPIO INIT ---------------- */

static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  GPIO_InitStruct.Pin = DISP_NRESET_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(DISP_NRESET_GPIO_Port, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = SPI1_DCX_Pin | SPI1_NCS_Pin;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

/* CLOCK CONFIG SAME AS YOUR PREVIOUS WORKING VERSION */

void Error_Handler(void)
{
  __disable_irq();
  while (1) {}
}
